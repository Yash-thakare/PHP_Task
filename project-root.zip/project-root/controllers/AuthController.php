<?php
require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../helpers/auth.php';

class AuthController {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    public function register() {
        $data = json_decode(file_get_contents("php://input"), true);

        if (empty($data['username']) || empty($data['password'])) {
            http_response_code(400);
            echo json_encode(["message" => "Username and Password are required"]);
            return;
        }

        $user = new User($this->db);
        $user->username = $data['username'];
        $user->password_hash = password_hash($data['password'], PASSWORD_BCRYPT);

        if ($user->register()) {
            http_response_code(201);
            echo json_encode(["message" => "User registered successfully"]);
        } else {
            http_response_code(400);
            echo json_encode(["message" => "Username already exists"]);
        }
    }

    public function login() {
        $data = json_decode(file_get_contents("php://input"), true);

        if (empty($data['username']) || empty($data['password'])) {
            http_response_code(400);
            echo json_encode(["message" => "Username and Password are required"]);
            return;
        }

        $user = new User($this->db);
        $user->username = $data['username'];
        $user->password_hash = $data['password'];

        $result = $user->login();

        if ($result) {
            $token = generateToken($result['id']);
            echo json_encode(["token" => $token]);
        } else {
            http_response_code(401);
            echo json_encode(["message" => "Invalid credentials"]);
        }
    }
}
?>
