<?php

require_once __DIR__ . '/../models/Task.php';
require_once __DIR__ . '/../helpers/auth.php';

class TaskController {
    private $db;
    private $user_id;

    public function __construct($db) {
        $this->db = $db;

        $token = getBearerToken();
        if (!$token) {
            http_response_code(401);
            echo json_encode(["message" => "Authorization Token not found"]);
            exit;
        }

        $userId = verifyToken($token);
        if (!$userId) {
            http_response_code(401);
            echo json_encode(["message" => "Invalid or Expired Token"]);
            exit;
        }

        $this->user_id = $userId;
    }

    public function getAll() {
        $task = new Task($this->db);
        $task->user_id = $this->user_id;

        $tasks = $task->getAll();
        http_response_code(200);
        echo json_encode($tasks);
    }

    public function create() {
        $data = json_decode(file_get_contents("php://input"), true);

        if (empty($data['title']) || empty($data['description'])) {
            http_response_code(400);
            echo json_encode(["message" => "Title and Description are required"]);
            return;
        }

        $task = new Task($this->db);
        $task->user_id = $this->user_id;
        $task->title = htmlspecialchars(strip_tags($data['title']));
        $task->description = htmlspecialchars(strip_tags($data['description']));
        $task->status = isset($data['status']) ? $data['status'] : 'pending';

        if ($task->create()) {
            http_response_code(201);
            echo json_encode(["message" => "Task created successfully"]);
        } else {
            http_response_code(500);
            echo json_encode(["message" => "Failed to create task"]);
        }
    }

    public function getSingle($id) {
        if (!is_numeric($id)) {
            http_response_code(400);
            echo json_encode(["message" => "Invalid Task ID"]);
            return;
        }

        $task = new Task($this->db);
        $task->id = $id;
        $task->user_id = $this->user_id;

        $data = $task->getSingle();
        if ($data) {
            http_response_code(200);
            echo json_encode($data);
        } else {
            http_response_code(404);
            echo json_encode(["message" => "Task not found"]);
        }
    }

    public function update($id) {
        if (!is_numeric($id)) {
            http_response_code(400);
            echo json_encode(["message" => "Invalid Task ID"]);
            return;
        }

        $data = json_decode(file_get_contents("php://input"), true);

        if (empty($data['title']) || empty($data['description']) || empty($data['status'])) {
            http_response_code(400);
            echo json_encode(["message" => "Title, Description and Status are required"]);
            return;
        }

        $task = new Task($this->db);
        $task->id = $id;
        $task->user_id = $this->user_id;
        $task->title = htmlspecialchars(strip_tags($data['title']));
        $task->description = htmlspecialchars(strip_tags($data['description']));
        $task->status = htmlspecialchars(strip_tags($data['status']));

        if ($task->update()) {
            http_response_code(200);
            echo json_encode(["message" => "Task updated successfully"]);
        } else {
            http_response_code(400);
            echo json_encode(["message" => "Failed to update task"]);
        }
    }

    public function delete($id) {
        if (!is_numeric($id)) {
            http_response_code(400);
            echo json_encode(["message" => "Invalid Task ID"]);
            return;
        }

        $task = new Task($this->db);
        $task->id = $id;
        $task->user_id = $this->user_id;

        if ($task->delete()) {
            http_response_code(200);
            echo json_encode(["message" => "Task deleted successfully"]);
        } else {
            http_response_code(400);
            echo json_encode(["message" => "Failed to delete task"]);
        }
    }
}
?>
