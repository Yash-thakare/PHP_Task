<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");

require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$uri = str_replace('/project-root/public', '', $uri);

$method = $_SERVER['REQUEST_METHOD'];

require_once '../controllers/AuthController.php';
require_once '../controllers/TaskController.php';

if ($uri[2] == 'register' && $method == 'POST') {
    $controller = new AuthController($db);
    $controller->register();
} elseif ($uri[2] == 'login' && $method == 'POST') {
    $controller = new AuthController($db);
    $controller->login();
} elseif ($uri[2] == 'tasks') {
    $controller = new TaskController($db);

    if ($method == 'GET' && isset($uri[3])) {
        $controller->getSingle($uri[3]);
    } elseif ($method == 'GET') {
        $controller->getAll();
    } elseif ($method == 'POST') {
        $controller->create();
    } elseif ($method == 'PUT' && isset($uri[3])) {
        $controller->update($uri[3]);
    } elseif ($method == 'DELETE' && isset($uri[3])) {
        $controller->delete($uri[3]);
    } else {
        http_response_code(404);
        echo json_encode(["message" => "Not Found"]);
    }
} else {
    http_response_code(404);
    echo json_encode(["message" => "Endpoint not found"]);
}
?>
