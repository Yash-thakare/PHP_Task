<?php
class User {
    private $conn;


    public $id;
    public $username;
    public $password_hash;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function register() { // register method

        $query = "INSERT INTO 'users' (username, password_hash) VALUES (:username, :password_hash)";

        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(':username', $this->username);

        $stmt->bindParam(':password_hash', $this->password_hash);

        return $stmt->execute();
    }

    public function login() {   // login method
        $query = "SELECT * FROM 'users' WHERE username = :username LIMIT 1";

        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(':username', $this->username);

        $stmt->execute();

        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($user && password_verify($this->password_hash, $user['password_hash'])) {
            return $user;
        }
        return false;
    }
}
?>
