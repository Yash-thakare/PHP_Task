<?php
class Task {
    private $conn;  

    public $id;
    public $user_id;
    public $title;
    public $description;
    public $status;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function getAll($offset = 0, $limit = 10) {
        $query = "SELECT * FROM 'tasks' WHERE user_id = :user_id LIMIT :offset, :limit";
        
 
        $stmt = $this->conn->prepare($query);
        $stmt->bindValue(':user_id', $this->user_id, PDO::PARAM_INT);
    
        $stmt->bindValue(':offset', (int)$offset, PDO::PARAM_INT);
        $stmt->bindValue(':limit', (int)$limit, PDO::PARAM_INT);
   
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }







    public function create() {
        $query = "INSERT INTO 'tasks' (user_id, title, description, status) VALUES (:user_id, :title, :description, :status)";
        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(':user_id', $this->user_id);
        $stmt->bindParam(':title', $this->title);
        $stmt->bindParam(':description', $this->description);
        $stmt->bindParam(':status', $this->status);

        return $stmt->execute();
    }










    public function getSingle() {
        $query = "SELECT * FROM 'tasks' WHERE id = :id AND user_id = :user_id LIMIT 1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $this->id);
        $stmt->bindParam(':user_id', $this->user_id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }






    public function update() {
        $query = "UPDATE 'tasks' SET title = :title, description = :description, status = :status WHERE id = :id AND user_id = :user_id";
        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(':title', $this->title);
        $stmt->bindParam(':description', $this->description);
        $stmt->bindParam(':status', $this->status);
        $stmt->bindParam(':id', $this->id);
        $stmt->bindParam(':user_id', $this->user_id);

        return $stmt->execute();
    }







    public function delete() {
        $query = "DELETE FROM 'tasks' WHERE id = :id AND user_id = :user_id";
        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(':id', $this->id);
        $stmt->bindParam(':user_id', $this->user_id);

        return $stmt->execute();
    }
}
?>
