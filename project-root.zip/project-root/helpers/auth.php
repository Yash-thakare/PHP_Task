<?php
function generateToken($userId) {
    $header = base64_encode(json_encode(["alg" => "HS256", "typ" => "JWT"]));
    $payload = base64_encode(json_encode(["user_id" => $userId, "exp" => time() + (3600 * 24)]));
    $signature = hash_hmac('sha256', "$header.$payload", "y8oP@k3fj!A4t2d9ZwQs8XxLp7oKiVbM", true);
    $signature = base64_encode($signature);
    return "$header.$payload.$signature";
}

function verifyToken($token) {
    $parts = explode('.', $token);
    if (count($parts) !== 3) {
        return false;
    }

    [$header, $payload, $signature] = $parts;
    $valid_signature = base64_encode(hash_hmac('sha256', "$header.$payload", "SECRET_KEY", true));

    if ($signature !== $valid_signature) {
        return false;
    }

    $payload = json_decode(base64_decode($payload), true);
    if ($payload['exp'] < time()) {
        return false;
    }

    return $payload['user_id'];
}

function getBearerToken() {
    $headers = apache_request_headers();
    if (isset($headers['Authorization'])) {
        if (preg_match('/Bearer\s(\S+)/', $headers['Authorization'], $matches)) {
            return $matches[1];
        }
    }
    return null;
}
?>
